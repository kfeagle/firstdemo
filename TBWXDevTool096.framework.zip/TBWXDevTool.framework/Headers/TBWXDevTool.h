//
//  TBWXDevTool.h
//  TBWXDevTool
//
//  Created by yangshengtao on 16/7/6.
//  Copyright © 2016年 Taobao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for WXDevTool.
FOUNDATION_EXPORT double WXDevToolVersionNumber;

//! Project version string for WXDevTool.
FOUNDATION_EXPORT const unsigned char WXDevToolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WXDevTool/PublicHeader.h>

#import <TBWXDevTool/WXDevTool.h>


